package net.minecraft.src;

public class ItemFireworkCharge extends Item {
	public ItemFireworkCharge(int par1) {
		super(par1);
	}
}
