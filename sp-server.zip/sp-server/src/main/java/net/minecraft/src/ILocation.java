package net.minecraft.src;

public interface ILocation extends IPosition {
	World getWorld();
}
