package net.minecraft.src;

class ServerBlockEvent {
}
