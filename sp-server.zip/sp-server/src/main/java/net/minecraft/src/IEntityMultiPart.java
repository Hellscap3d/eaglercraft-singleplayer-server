package net.minecraft.src;

public interface IEntityMultiPart {
	World func_82194_d();

	boolean attackEntityFromPart(EntityDragonPart var1, DamageSource var2, int var3);
}
