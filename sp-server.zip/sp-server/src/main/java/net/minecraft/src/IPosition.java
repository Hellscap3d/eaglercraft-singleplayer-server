package net.minecraft.src;

public interface IPosition {
	double getX();

	double getY();

	double getZ();
}
