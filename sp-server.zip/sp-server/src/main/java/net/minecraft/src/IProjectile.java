package net.minecraft.src;

public interface IProjectile {
	/**
	 * Similar to setArrowHeading, it's point the throwable entity to a x, y, z
	 * direction.
	 */
	void setThrowableHeading(double var1, double var3, double var5, float var7, float var8);
}
