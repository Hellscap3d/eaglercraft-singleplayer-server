package net.minecraft.src;

final class CreativeTabCombat extends CreativeTabs {
	CreativeTabCombat(int par1, String par2Str) {
		super(par1, par2Str);
	}
}
